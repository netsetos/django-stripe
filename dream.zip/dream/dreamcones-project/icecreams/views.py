from django.shortcuts import render
from .forms import IceForm,MultipleIceForm
from django.forms import formset_factory
from .forms import CustomSignupForm
from django.urls import reverse_lazy
from .models import Icecream
from django.views import generic
from django.contrib.auth import authenticate, login

def home(request):
    return render(request,'icecreams/home.html')

def order(request):
    multiple_form=MultipleIceForm()
    if(request.method == 'POST'):
        filled_form = IceForm(request.POST)
        if(filled_form.is_valid()):
            prepared_icecream=filled_form.save()
            prepared_icecream_pk=prepared_icecream.id
            note = "Thanks for Ordering! Your %s %s and %s Icecream is on its way!" %(filled_form.cleaned_data['size'],
            filled_form.cleaned_data['topping1'],
            filled_form.cleaned_data['topping2'],)
            filled_form = IceForm()
        else:
            prepared_icecream_pk = None
            note = "Icecream Order has Failed.Please Try Again!!!"
        return render(request, 'icecreams/order.html', {'prepared_icecream_pk':prepared_icecream_pk,'IceForm': filled_form,'note':note,'multiple_form':multiple_form})

    else:
        form = IceForm()
        return render(request,'icecreams/order.html',{'IceForm':form,'multiple_form':multiple_form})

def join(request):
    return render(request, 'icecreams/a.html')

def checkout(request):
    return render(request, 'plans/checkout.html')

class SignUp(generic.CreateView):
    form_class = CustomSignupForm
    success_url = reverse_lazy('home')
    template_name = 'registration/signup.html'

    def form_valid(self, form):
        valid = super(SignUp, self).form_valid(form)
        username, password = form.cleaned_data.get('username'), form.cleaned_data.get('password1')
        new_user = authenticate(username=username, password=password)
        login(self.request, new_user)
        return valid

def icecreams(request):
    num_of_icecreams = 2
    filled_multi_ice_form = MultipleIceForm(request.GET)
    if(filled_multi_ice_form.is_valid()):
        num_of_icecreams = filled_multi_ice_form.cleaned_data['numofice']
    IceFormSet = formset_factory(IceForm,extra = num_of_icecreams)
    formset = IceFormSet()
    if(request.method == 'POST'):
        filled_formset = IceFormSet(request.POST)
        if(filled_formset.is_valid()):
            for form in filled_formset:
                print(form.cleaned_data['topping1'])
                note = 'Icecreams have been ordered'
        else:
            note = 'Order has not been created.Please Try Again!!'

        return render(request,'icecreams/icecreams.html',{'note':note,'formset':formset})

    else:
        return render(request, 'icecreams/icecreams.html', {'formset': formset})

def edit_order(request,pk):
    icecream=Icecream.objects.get(pk=pk)
    form = IceForm(instance = icecream)
    if(request.method == 'POST'):
        filled_form = IceForm(request.POST,instance=icecream)
        if(filled_form.is_valid()):
            filled_form.save()
            form=filled_form
            note='Order has been Updated'
            return render(request,'icecreams/edit_order.html',{'note':note,'IceForm':form,'icecream':icecream})
    return render(request,'icecreams/edit_order.html',{'IceForm':form,'icecream':icecream})

def settings(request):
    return render(request, 'registration/settings.html')