from django.apps import AppConfig


class IcecreamsConfig(AppConfig):
    name = 'icecreams'
