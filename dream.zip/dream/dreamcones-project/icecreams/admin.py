from django.contrib import admin
from .models import Icecream,Size

admin.site.register(Icecream)
admin.site.register(Size)
